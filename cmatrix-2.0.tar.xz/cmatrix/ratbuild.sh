autoreconf -i
./configure --prefix=/usr
make
make install
